Configure your first networks
=============================

A newly deployed OpenStack-Ansible has no networks by default. If you need to
add networks, you can use the openstack CLI, or you can use the ansible modules
for it.

An example for the latter is in the ``openstack-ansible-ops`` repository,
under the ``openstack-service-setup.yml`` playbook.
