===========================
Monitoring your environment
===========================

This is a draft monitoring system page for the proposed OpenStack-Ansible
operations guide.


.. TODO monitoring, at a high level, describe how to monitor the services,
   and how does haproxy currently check system health (because it can influence
   the monitoring process, and ppl may not be aware of the internals.
