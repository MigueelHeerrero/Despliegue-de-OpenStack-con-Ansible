.. _openstack-user-config-reference:

openstack_user_config settings reference
========================================

The ``openstack_user_config.yml.example`` file is heavily commented with the
details of how to do more advanced container networking configuration. The
contents of the file are shown here for reference.

.. literalinclude:: ../../../../etc/openstack_deploy/openstack_user_config.yml.example
   :language: yaml
   :start-after: under the License.
