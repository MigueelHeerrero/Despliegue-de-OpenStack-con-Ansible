====================
Additional resources
====================

Ansible resources:

- `Ansible Documentation
  <http://docs.ansible.com/ansible/>`_

- `Ansible Best Practices
  <http://docs.ansible.com/ansible/playbooks_best_practices.html>`_

- `Ansible Configuration
  <http://docs.ansible.com/ansible/intro_configuration.html>`_

OpenStack resources:

- `OpenStack Documentation <https://docs.openstack.org/>`_

- `OpenStack API Guide
  <https://docs.openstack.org/api-quick-start>`_

- `OpenStack Project Developer Documentation
  <https://docs.openstack.org/developer>`_
