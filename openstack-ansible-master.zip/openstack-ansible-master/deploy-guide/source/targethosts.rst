.. _target-hosts:

========================
Prepare the target hosts
========================

.. figure:: figures/installation-workflow-targethosts.png
   :width: 100%

.. include:: targethosts-prepare.rst
.. include:: targethosts-networkconfig.rst
